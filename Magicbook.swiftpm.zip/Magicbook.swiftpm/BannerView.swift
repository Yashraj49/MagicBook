
//  ContentView.swift
//  About
//
//  Created by Yashraj jadhav on 20/04/22.


import SwiftUI


struct BannerView: View {
    //MARK: - PROPERTIES
    @State var button = true
    var card: [Card] = cardData
    
    
    //MARK: - CONTENT
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            
            HStack (alignment: .center, spacing: 10) {
                ForEach(card) { item in
                    if button { CardView(card: item, button: $button)
                        //Text("Card")
                    }
                    
                }
                
            }
            .padding(25)
        }
    }
    
}
//MARK: - PREVIEW
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        BannerView(card: cardData)
            .previewDevice("iPhone 13 Pro")
    }
}


