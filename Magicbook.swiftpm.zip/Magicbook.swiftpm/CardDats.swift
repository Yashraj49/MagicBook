//
//  CardDats.swift
//  About
//
//  Created by Yashraj jadhav on 21/04/22.
//

import SwiftUI

let cardData: [Card] = [
    Card(
        title: "Magic Book",
        headline:" An impressive AR experince " ,
        
        imageName: "developer-no1",
        callToAction: "",
        
        gradientColors: [Color("Color01"), Color("Color02")]),
    
    Card(
        title: "How it Works ?? ",
        headline:
            " well you need to have an image associated with the video. To play the video, just place the device over a image area and the video starts playing , hold the device properly and keep it steady, dont move it else the video will be not able to play seemlessly.",
        
        imageName: "developer-no2",
        
        callToAction: "Open AR Camera",
        
        gradientColors: [Color("Color03"), Color("Color04")]) //.
    
    
    //    Card(
    //        title: "Swift 5",
    //        headline: "Everyone can code.",
    //
    //        imageName: "developer-no3",
    //
    //        callToAction: "Implement",
    //
    //        gradientColors: [Color("Color05"), Color("Color06")])
]



